# PDES — Personal Data Exposure Scanner

> **Subject:** Information Security  
> **Student:** Abubakar Javed &nbsp;|&nbsp; Roll No: FA24-BCS-429-D  
> **Instructor:** Prof. Ahmad Farid  
> **Campus:** COMSATS University Islamabad – Sahiwal Campus

---

## Project Overview

PDES is an ethical, Flask-based cybersecurity tool that demonstrates how OSINT-style
Personal Data Exposure Scanners work. It uses a **SQLite database** (simulating MySQL)
pre-seeded with synthetic breach datasets to show exposure analysis, risk scoring, and
actionable security recommendations.

---

## Features

| Feature | Detail |
|---|---|
| 🔍 Exposure Scanning | Email, Username, Phone Number lookups |
| 📊 Risk Scoring | 0–100 score, 4 levels: Low / Moderate / High / Critical |
| 🗺️ Platform Map | Visual map of exposure across platforms |
| 📋 Tabbed Reports | Separate detail views per data type |
| 💡 Recommendations | Prioritised, actionable security guidance |
| 📈 Live Counters | Real-time scan & record statistics |
| 🎨 Cybersecurity UI | 60/30/10 color rule, dark theme, animated gauge |

---

## Tech Stack

| Layer | Technology |
|---|---|
| Language | Python 3.x |
| Web Framework | Flask |
| Database | SQLite (simulates MySQL schema) |
| Front-End | HTML5, CSS3, Vanilla JS |
| Icons | Lucide Icons (CDN) |
| Fonts | Syne + Space Mono + Inter (Google Fonts) |

---

## Setup & Run

```bash
# 1. Clone / extract the project
cd PDES

# 2. Create virtual environment
python -m venv venv

# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the application
python app.py
```

Then open your browser at: **http://127.0.0.1:5000**

---

## Sample Inputs (Pre-seeded in Database)

| Type | Value |
|---|---|
| Email | `john.doe@gmail.com` |
| Email | `test@example.com` |
| Email | `admin@company.com` |
| Username | `hacker101` |
| Username | `john_doe` |
| Phone | `+92-300-1234567` |
| Phone | `+1-555-0100` |

---

## Risk Score Methodology

```
Each exposure adds to cumulative score:
  CRITICAL platform  → 25 pts (×1.5 if dark web/broker)
  HIGH     platform  → 15 pts
  MEDIUM   platform  →  8 pts
  LOW      platform  →  3 pts

Score capped at 100.

Classification:
  0–24   → Low      (Green)
  25–49  → Moderate (Yellow)
  50–74  → High     (Orange)
  75–100 → Critical (Red)
```

---

## Project Structure

```
PDES/
├── app.py                  ← Flask entry point
├── requirements.txt
├── README.md
├── database/
│   ├── __init__.py
│   └── db_manager.py       ← SQLite / MySQL-compatible DB layer
├── scanner/
│   ├── __init__.py
│   └── exposure_engine.py  ← Risk scoring & report generation
├── templates/
│   └── index.html          ← Full SPA-style template
└── static/
    ├── css/
    │   └── style.css       ← 60/30/10 cybersecurity theme
    └── js/
        └── app.js          ← Fetch API, gauge animation, tabs
```

---

## Ethical Disclaimer

This project uses **only simulated datasets**. No real breach databases, private APIs,
or unauthorized data sources are accessed. It is intended purely for educational purposes
to demonstrate cybersecurity awareness and OSINT principles.

---

*Built with ❤️ for Information Security — COMSATS University Islamabad*
