"""
database/db_manager.py
Simulates a MySQL database using SQLite for portability.
Schema mirrors the proposal: emails, usernames, phone_numbers tables.
"""

import sqlite3, os, random, hashlib
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(__file__), "pdes.db")

# ── Sample platforms used in breach simulation ────────────────────────────────
PLATFORMS = [
    ("LinkedIn",      "Professional Network", "high"),
    ("Twitter/X",     "Social Media",         "medium"),
    ("Facebook",      "Social Media",         "high"),
    ("GitHub",        "Developer Platform",   "medium"),
    ("Reddit",        "Forum",                "low"),
    ("Adobe",         "SaaS",                 "high"),
    ("Dropbox",       "Cloud Storage",        "high"),
    ("Canva",         "Design Tool",          "medium"),
    ("Twitch",        "Gaming/Streaming",     "medium"),
    ("Pastebin",      "Public Paste",         "critical"),
    ("HaveIBeenPwned","Breach DB",            "critical"),
    ("MySpace",       "Legacy Social",        "high"),
    ("Tumblr",        "Blog Platform",        "medium"),
    ("Gravatar",      "Avatar Service",       "low"),
    ("Snapchat",      "Social Media",         "medium"),
    ("Discord",       "Messaging",            "medium"),
    ("Slack",         "Team Messaging",       "high"),
    ("Zoom",          "Video Conf",           "high"),
    ("DarkWeb Forum", "Dark Web",             "critical"),
    ("Data Broker",   "Data Aggregator",      "critical"),
]

# ── Breach years for realism ──────────────────────────────────────────────────
BREACH_YEARS = [2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024]

# ── Seeded test data (deterministic via hash) ─────────────────────────────────
SEEDED_EMAILS = [
    "john.doe@gmail.com", "jane.smith@yahoo.com", "alice@hotmail.com",
    "bob@outlook.com", "test@example.com", "admin@company.com",
    "user123@protonmail.com", "contact@domain.org", "info@startup.io",
    "dev@techcorp.com", "abubakar@email.com", "victim@exposed.net",
    "mark.zuckerberg@facebook.com", "elon@tesla.com", "security@breach.org",
    "support@phished.com", "noreply@leakdb.io", "hacked@darkforum.onion",
    "sample@university.edu", "personal@private.net",
]

SEEDED_USERNAMES = [
    "john_doe", "jane.smith", "alice123", "bob_marley", "admin",
    "root", "hacker101", "coder_x", "darkweb_user", "exposed_one",
    "abubakar_javed", "cyber_sec", "redteam", "pentest_pro",
    "privacy_ghost", "anon_user", "tech_geek99", "zero_day",
    "security_ninja", "osint_master",
]

SEEDED_PHONES = [
    "+1-555-0100", "+44-7700-900001", "+92-300-1234567",
    "+1-800-555-0199", "+49-30-12345678", "+33-1-23456789",
    "+61-412-345678", "+81-90-1234-5678", "+92-321-9876543",
    "+1-212-555-0147",
]


class DatabaseManager:
    def __init__(self):
        self.db_path = DB_PATH

    # ──────────────────────────────────────────────────────────────────────────
    def init_db(self):
        conn = self._connect()
        c = conn.cursor()

        # ── Create tables ─────────────────────────────────────────────────────
        c.execute("""
            CREATE TABLE IF NOT EXISTS emails (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                email       TEXT NOT NULL,
                platform    TEXT NOT NULL,
                category    TEXT NOT NULL,
                severity    TEXT NOT NULL,
                breach_year INTEGER NOT NULL,
                source      TEXT NOT NULL,
                hash_sha256 TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS usernames (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                username    TEXT NOT NULL,
                platform    TEXT NOT NULL,
                category    TEXT NOT NULL,
                severity    TEXT NOT NULL,
                breach_year INTEGER NOT NULL,
                profile_url TEXT
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS phone_numbers (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                phone       TEXT NOT NULL,
                platform    TEXT NOT NULL,
                category    TEXT NOT NULL,
                severity    TEXT NOT NULL,
                breach_year INTEGER NOT NULL,
                country     TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS scan_logs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_time   TEXT NOT NULL,
                email       TEXT,
                username    TEXT,
                phone       TEXT,
                risk_score  INTEGER,
                risk_level  TEXT
            )
        """)
        conn.commit()

        # ── Seed if empty ──────────────────────────────────────────────────────
        if c.execute("SELECT COUNT(*) FROM emails").fetchone()[0] == 0:
            self._seed(conn, c)

        conn.close()

    # ──────────────────────────────────────────────────────────────────────────
    def _seed(self, conn, c):
        """Populate tables with realistic simulated breach data."""
        random.seed(42)

        # Emails
        email_rows = []
        for email in SEEDED_EMAILS:
            num_exposures = random.randint(1, 6)
            chosen = random.sample(PLATFORMS, min(num_exposures, len(PLATFORMS)))
            for plat, cat, sev in chosen:
                yr = random.choice(BREACH_YEARS)
                h  = hashlib.sha256(f"{email}{plat}".encode()).hexdigest()[:12]
                email_rows.append((email, plat, cat, sev, yr,
                                   f"Data breach via {plat} ({yr})", h))
        c.executemany(
            "INSERT INTO emails (email,platform,category,severity,breach_year,source,hash_sha256)"
            " VALUES (?,?,?,?,?,?,?)", email_rows)

        # Usernames
        user_rows = []
        for uname in SEEDED_USERNAMES:
            num = random.randint(1, 5)
            chosen = random.sample(PLATFORMS, min(num, len(PLATFORMS)))
            for plat, cat, sev in chosen:
                yr  = random.choice(BREACH_YEARS)
                url = f"https://{plat.lower().replace(' ', '')}.example/u/{uname}"
                user_rows.append((uname, plat, cat, sev, yr, url))
        c.executemany(
            "INSERT INTO usernames (username,platform,category,severity,breach_year,profile_url)"
            " VALUES (?,?,?,?,?,?)", user_rows)

        # Phones
        COUNTRIES = ["USA","UK","Pakistan","Germany","France","Australia","Japan"]
        phone_rows = []
        for phone in SEEDED_PHONES:
            num = random.randint(1, 4)
            chosen = random.sample(PLATFORMS, min(num, len(PLATFORMS)))
            for plat, cat, sev in chosen:
                yr  = random.choice(BREACH_YEARS)
                cty = random.choice(COUNTRIES)
                phone_rows.append((phone, plat, cat, sev, yr, cty))
        c.executemany(
            "INSERT INTO phone_numbers (phone,platform,category,severity,breach_year,country)"
            " VALUES (?,?,?,?,?,?)", phone_rows)

        conn.commit()

    # ──────────────────────────────────────────────────────────────────────────
    def _connect(self):
        return sqlite3.connect(self.db_path)

    # ──────────────────────────────────────────────────────────────────────────
    def query_email(self, email: str):
        conn = self._connect()
        c    = conn.cursor()
        c.execute("SELECT platform,category,severity,breach_year,source,hash_sha256"
                  " FROM emails WHERE LOWER(email)=LOWER(?)", (email,))
        rows = c.fetchall()
        conn.close()
        return [{"platform": r[0], "category": r[1], "severity": r[2],
                 "breach_year": r[3], "source": r[4], "hash": r[5]}
                for r in rows]

    def query_username(self, username: str):
        conn = self._connect()
        c    = conn.cursor()
        c.execute("SELECT platform,category,severity,breach_year,profile_url"
                  " FROM usernames WHERE LOWER(username)=LOWER(?)", (username,))
        rows = c.fetchall()
        conn.close()
        return [{"platform": r[0], "category": r[1], "severity": r[2],
                 "breach_year": r[3], "profile_url": r[4]}
                for r in rows]

    def query_phone(self, phone: str):
        conn = self._connect()
        c    = conn.cursor()
        cleaned = phone.replace(" ", "").replace("-", "")
        c.execute("SELECT platform,category,severity,breach_year,country"
                  " FROM phone_numbers WHERE REPLACE(REPLACE(phone,' ',''),'-','')=?",
                  (cleaned,))
        rows = c.fetchall()
        conn.close()
        return [{"platform": r[0], "category": r[1], "severity": r[2],
                 "breach_year": r[3], "country": r[4]}
                for r in rows]

    def log_scan(self, email, username, phone, risk_score, risk_level):
        conn = self._connect()
        c    = conn.cursor()
        c.execute(
            "INSERT INTO scan_logs (scan_time,email,username,phone,risk_score,risk_level)"
            " VALUES (?,?,?,?,?,?)",
            (datetime.now().isoformat(), email, username, phone, risk_score, risk_level)
        )
        conn.commit()
        conn.close()

    def get_stats(self):
        conn = self._connect()
        c    = conn.cursor()
        total_emails    = c.execute("SELECT COUNT(DISTINCT email)    FROM emails").fetchone()[0]
        total_usernames = c.execute("SELECT COUNT(DISTINCT username) FROM usernames").fetchone()[0]
        total_phones    = c.execute("SELECT COUNT(DISTINCT phone)    FROM phone_numbers").fetchone()[0]
        total_scans     = c.execute("SELECT COUNT(*) FROM scan_logs").fetchone()[0]
        total_records   = c.execute("SELECT COUNT(*) FROM emails").fetchone()[0] + \
                          c.execute("SELECT COUNT(*) FROM usernames").fetchone()[0] + \
                          c.execute("SELECT COUNT(*) FROM phone_numbers").fetchone()[0]
        conn.close()
        return {
            "emails_in_db":    total_emails,
            "usernames_in_db": total_usernames,
            "phones_in_db":    total_phones,
            "total_scans":     total_scans,
            "total_records":   total_records,
        }
