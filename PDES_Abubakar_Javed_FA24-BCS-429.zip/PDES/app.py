"""
Personal Data Exposure Scanner (PDES)
--------------------------------------
A Flask-based cybersecurity tool that simulates OSINT-style exposure
detection using a MySQL database of pre-seeded datasets.

Author  : Abubakar Javed  |  FA24-BCS-429-D
Subject : Information Security  |  Prof. Ahmad Farid
Campus  : COMSATS University Islamabad – Sahiwal Campus
"""

from flask import Flask, render_template, request, jsonify, session
from database.db_manager import DatabaseManager
from scanner.exposure_engine import ExposureEngine
import json, datetime, os, re

app = Flask(__name__)
app.secret_key = os.urandom(24)

db = DatabaseManager()
engine = ExposureEngine(db)


# ──────────────────────────────────────────────────────────────────────────────
# ROUTES
# ──────────────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/scan", methods=["POST"])
def scan():
    data = request.get_json()

    email    = data.get("email", "").strip()
    username = data.get("username", "").strip()
    phone    = data.get("phone", "").strip()

    # ── basic validation ──────────────────────────────────────────────────────
    errors = []
    if not email and not username and not phone:
        return jsonify({"error": "Please provide at least one field to scan."}), 400

    if email and not re.match(r"^[\w.+-]+@[\w-]+\.[a-zA-Z]{2,}$", email):
        errors.append("Invalid email format.")
    if phone and not re.match(r"^\+?[\d\s\-]{7,15}$", phone):
        errors.append("Invalid phone number format.")
    if errors:
        return jsonify({"error": " ".join(errors)}), 400

    # ── run scan ──────────────────────────────────────────────────────────────
    report = engine.run_scan(email=email, username=username, phone=phone)
    return jsonify(report)


@app.route("/stats")
def stats():
    """Return global statistics for the dashboard counters."""
    s = db.get_stats()
    return jsonify(s)


if __name__ == "__main__":
    db.init_db()
    print("\n  ┌───────────────────────────────────────────────┐")
    print("  │   PDES – Personal Data Exposure Scanner       │")
    print("  │   http://127.0.0.1:5000                       │")
    print("  └───────────────────────────────────────────────┘\n")
    app.run(debug=True, port=5000)
