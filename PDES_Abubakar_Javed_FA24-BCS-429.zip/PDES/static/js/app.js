/**
 * PDES – Personal Data Exposure Scanner
 * Frontend Application Script
 */

"use strict";

// ─── Lucide icons init ────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  if (window.lucide) lucide.createIcons();
  loadStats();
  setupHints();
  setupTabs();
  setupForm();
  setupNewScan();
});

// ─── Load global stats ────────────────────────────────────────────────────────
async function loadStats() {
  try {
    const res  = await fetch("/stats");
    const data = await res.json();
    animateCounter("cnt-records", data.total_records);
    animateCounter("cnt-emails",  data.emails_in_db);
    animateCounter("cnt-scans",   data.total_scans);
  } catch (e) {
    console.warn("Stats unavailable:", e);
  }
}

function animateCounter(id, target) {
  const el = document.getElementById(id);
  if (!el) return;
  const duration = 1400;
  const start    = performance.now();
  const update   = (now) => {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased    = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(eased * target).toLocaleString();
    if (progress < 1) requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
}

// ─── Hint pills ──────────────────────────────────────────────────────────────
function setupHints() {
  document.querySelectorAll(".hint-pill").forEach((pill) => {
    pill.addEventListener("click", () => {
      const email = pill.dataset.email || "";
      const user  = pill.dataset.user  || "";
      const phone = pill.dataset.phone || "";
      document.getElementById("f-email").value    = email;
      document.getElementById("f-username").value = user;
      document.getElementById("f-phone").value    = phone;
    });
  });
}

// ─── Tab system ──────────────────────────────────────────────────────────────
function setupTabs() {
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const tab = btn.dataset.tab;
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach(c => c.classList.add("hidden"));
      btn.classList.add("active");
      document.getElementById("tab-" + tab).classList.remove("hidden");
    });
  });
}

// ─── Form submit ─────────────────────────────────────────────────────────────
function setupForm() {
  document.getElementById("scan-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    clearError();

    const email    = document.getElementById("f-email").value.trim();
    const username = document.getElementById("f-username").value.trim();
    const phone    = document.getElementById("f-phone").value.trim();

    if (!email && !username && !phone) {
      showError("Please provide at least one field to scan.");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, username, phone }),
      });
      const data = await res.json();

      if (!res.ok) {
        showError(data.error || "Scan failed. Please try again.");
        return;
      }

      renderResults(data);
    } catch (err) {
      showError("Network error. Is the Flask server running?");
    } finally {
      setLoading(false);
    }
  });
}

function setupNewScan() {
  document.getElementById("new-scan-btn").addEventListener("click", () => {
    document.getElementById("results-section").classList.add("hidden");
    document.getElementById("scan-form-section").scrollIntoView({ behavior: "smooth" });
    loadStats(); // refresh counter
  });
}

// ─── Render results ───────────────────────────────────────────────────────────
function renderResults(d) {
  // Meta
  document.getElementById("r-scan-id").textContent   = d.scan_id;
  document.getElementById("r-scan-time").textContent  = d.scan_time;
  document.getElementById("r-total-exp").textContent  = d.stats.total_exposures;

  // Stats pills
  document.getElementById("sp-email").textContent = d.stats.email_exposures;
  document.getElementById("sp-user").textContent  = d.stats.username_exposures;
  document.getElementById("sp-phone").textContent = d.stats.phone_exposures;

  // Tab counts
  document.getElementById("tab-count-email").textContent    = d.stats.email_exposures;
  document.getElementById("tab-count-username").textContent = d.stats.username_exposures;
  document.getElementById("tab-count-phone").textContent    = d.stats.phone_exposures;

  // Gauge
  animateGauge(d.risk_score, d.risk_level);

  // Platform summary
  renderPlatforms(d.platform_summary);

  // Exposure lists
  renderEmailList(d.exposures.email);
  renderUsernameList(d.exposures.username);
  renderPhoneList(d.exposures.phone);

  // Recommendations
  renderRecs(d.recommendations);

  // Show results
  const section = document.getElementById("results-section");
  section.classList.remove("hidden");
  section.classList.add("fade-in");
  section.scrollIntoView({ behavior: "smooth", block: "start" });

  // Re-init Lucide for dynamically added icons
  if (window.lucide) lucide.createIcons();
}

// ─── Gauge animation ─────────────────────────────────────────────────────────
function animateGauge(score, level) {
  const FULL_ARC  = 283; // half-circle arc length for r=90
  const fill      = document.getElementById("gauge-fill");
  const scoreEl   = document.getElementById("gauge-score");
  const badgeEl   = document.getElementById("gauge-badge");

  // Color map
  const colorMap = {
    Critical: "#ff2d55",
    High:     "#ff6b00",
    Moderate: "#ffd60a",
    Low:      "#30d158",
  };
  const color = colorMap[level.level] || "#00f5ff";

  fill.style.stroke = color;

  // Animate offset (283 = fully empty, 0 = fully filled)
  const targetOffset = FULL_ARC - (score / 100) * FULL_ARC;
  setTimeout(() => {
    fill.style.strokeDashoffset = targetOffset;
  }, 100);

  // Animate number
  const duration = 1200;
  const start    = performance.now();
  const tick     = (now) => {
    const t = Math.min((now - start) / duration, 1);
    const e = 1 - Math.pow(1 - t, 3);
    scoreEl.textContent = Math.round(e * score);
    if (t < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);

  // Badge
  badgeEl.textContent         = level.badge;
  badgeEl.style.color         = color;
  badgeEl.style.background    = color + "22";
  badgeEl.style.borderColor   = color + "44";
}

// ─── Platform summary ─────────────────────────────────────────────────────────
function renderPlatforms(platforms) {
  const grid = document.getElementById("platform-grid");
  if (!platforms.length) {
    grid.innerHTML = emptyState("No platform exposures detected.");
    return;
  }
  grid.innerHTML = platforms.map(p => `
    <div class="platform-card border-${p.severity}">
      <span class="pc-name">${esc(p.platform)}</span>
      <span class="pc-cat">${esc(p.category)}</span>
      <span class="pc-sev sev-${p.severity}">${p.severity.toUpperCase()}</span>
    </div>
  `).join("");
}

// ─── Email list ───────────────────────────────────────────────────────────────
function renderEmailList(rows) {
  const el = document.getElementById("list-email");
  if (!rows.length) { el.innerHTML = emptyState("No email exposures found in our dataset."); return; }
  el.innerHTML = rows.map(r => `
    <div class="exposure-card">
      <div>
        <div class="ec-platform">${esc(r.platform)}</div>
        <div class="ec-meta">
          <span>${esc(r.category)}</span>
          <span>Breach Year: ${r.breach_year}</span>
        </div>
        <div class="ec-source">${esc(r.source)}</div>
        <div class="ec-hash">SHA256: ${r.hash}…</div>
      </div>
      <span class="ec-sev sev-${r.severity}">${r.severity.toUpperCase()}</span>
    </div>
  `).join("");
}

// ─── Username list ────────────────────────────────────────────────────────────
function renderUsernameList(rows) {
  const el = document.getElementById("list-username");
  if (!rows.length) { el.innerHTML = emptyState("No username exposures found in our dataset."); return; }
  el.innerHTML = rows.map(r => `
    <div class="exposure-card">
      <div>
        <div class="ec-platform">${esc(r.platform)}</div>
        <div class="ec-meta">
          <span>${esc(r.category)}</span>
          <span>Breach Year: ${r.breach_year}</span>
        </div>
        <div class="ec-source">${esc(r.profile_url)}</div>
      </div>
      <span class="ec-sev sev-${r.severity}">${r.severity.toUpperCase()}</span>
    </div>
  `).join("");
}

// ─── Phone list ───────────────────────────────────────────────────────────────
function renderPhoneList(rows) {
  const el = document.getElementById("list-phone");
  if (!rows.length) { el.innerHTML = emptyState("No phone exposures found in our dataset."); return; }
  el.innerHTML = rows.map(r => `
    <div class="exposure-card">
      <div>
        <div class="ec-platform">${esc(r.platform)}</div>
        <div class="ec-meta">
          <span>${esc(r.category)}</span>
          <span>Breach Year: ${r.breach_year}</span>
          <span>Country: ${r.country}</span>
        </div>
      </div>
      <span class="ec-sev sev-${r.severity}">${r.severity.toUpperCase()}</span>
    </div>
  `).join("");
}

// ─── Recommendations ──────────────────────────────────────────────────────────
function renderRecs(recs) {
  const grid = document.getElementById("recs-grid");
  const iconMap = {
    shield: `<i data-lucide="shield"></i>`,
    key: `<i data-lucide="key"></i>`,
    eye: `<i data-lucide="eye"></i>`,
    mail: `<i data-lucide="mail"></i>`,
    "user-x": `<i data-lucide="user-x"></i>`,
    settings: `<i data-lucide="settings"></i>`,
    user: `<i data-lucide="user"></i>`,
    smartphone: `<i data-lucide="smartphone"></i>`,
    "phone-off": `<i data-lucide="phone-off"></i>`,
    phone: `<i data-lucide="phone"></i>`,
    bell: `<i data-lucide="bell"></i>`,
    wifi: `<i data-lucide="wifi"></i>`,
    search: `<i data-lucide="search"></i>`,
  };
  const colorMap = { critical:"#ff2d55", high:"#ff6b00", medium:"#ffd60a", low:"#30d158" };

  grid.innerHTML = recs.map(r => {
    const color = colorMap[r.priority] || "#00f5ff";
    return `
    <div class="rec-card">
      <div class="rc-header">
        <div class="rc-icon" style="background:${color}18; color:${color}">
          ${iconMap[r.icon] || `<i data-lucide="info"></i>`}
        </div>
        <span class="rc-title">${esc(r.title)}</span>
      </div>
      <p class="rc-detail">${esc(r.detail)}</p>
      <span class="rc-priority sev-${r.priority}">${r.priority.toUpperCase()}</span>
    </div>`;
  }).join("");
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function setLoading(on) {
  const btn  = document.getElementById("scan-btn");
  const inner = btn.querySelector(".btn-inner");
  const loader = document.getElementById("btn-loader");
  btn.disabled = on;
  inner.classList.toggle("hidden", on);
  loader.classList.toggle("hidden", !on);
}

function showError(msg) {
  const el = document.getElementById("error-msg");
  document.getElementById("error-text").textContent = msg;
  el.classList.remove("hidden");
  if (window.lucide) lucide.createIcons();
}

function clearError() {
  document.getElementById("error-msg").classList.add("hidden");
}

function emptyState(msg) {
  return `<div class="empty-state">
    <i data-lucide="inbox"></i>
    <p>${msg}</p>
  </div>`;
}

function esc(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;");
}
