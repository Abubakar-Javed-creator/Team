"""
scanner/exposure_engine.py
Core risk-scoring and report-generation engine.
Mirrors the methodology described in the project proposal.
"""

from datetime import datetime
import random

# ── Severity weight map ───────────────────────────────────────────────────────
SEVERITY_WEIGHTS = {
    "critical": 25,
    "high":     15,
    "medium":    8,
    "low":       3,
}

# ── Platform sensitivity bonus ────────────────────────────────────────────────
SENSITIVE_PLATFORMS = {
    "DarkWeb Forum", "Data Broker", "Pastebin", "HaveIBeenPwned",
}

# ── Risk thresholds ───────────────────────────────────────────────────────────
def classify_risk(score: int) -> dict:
    if score >= 75:
        return {"level": "Critical", "color": "#ff2d55", "icon": "skull", "badge": "CRITICAL"}
    elif score >= 50:
        return {"level": "High",     "color": "#ff6b00", "icon": "alert-triangle", "badge": "HIGH"}
    elif score >= 25:
        return {"level": "Moderate", "color": "#ffd60a", "icon": "alert-circle",   "badge": "MODERATE"}
    else:
        return {"level": "Low",      "color": "#30d158", "icon": "shield-check",   "badge": "LOW"}


# ── Recommendations bank ──────────────────────────────────────────────────────
RECOMMENDATIONS = {
    "email": [
        {"title": "Enable Two-Factor Authentication",
         "detail": "Add 2FA to all accounts linked to this email immediately.",
         "priority": "critical", "icon": "shield"},
        {"title": "Change Your Passwords",
         "detail": "Use a strong, unique password for every service. Consider a password manager.",
         "priority": "high", "icon": "key"},
        {"title": "Check for Unauthorized Logins",
         "detail": "Review account activity logs for any suspicious sign-ins.",
         "priority": "high", "icon": "eye"},
        {"title": "Use an Email Alias",
         "detail": "Create a separate alias for public sign-ups to reduce exposure.",
         "priority": "medium", "icon": "mail"},
    ],
    "username": [
        {"title": "Avoid Username Reuse",
         "detail": "Using the same username across platforms links your digital identities.",
         "priority": "high", "icon": "user-x"},
        {"title": "Audit Your Public Profiles",
         "detail": "Review privacy settings on all detected platforms and remove unnecessary info.",
         "priority": "high", "icon": "settings"},
        {"title": "Use Pseudonyms for Public Forums",
         "detail": "Protect your real identity by not using your real name as a username.",
         "priority": "medium", "icon": "user"},
    ],
    "phone": [
        {"title": "Enable SIM Lock",
         "detail": "Contact your carrier to add a SIM PIN to prevent SIM-swapping attacks.",
         "priority": "critical", "icon": "smartphone"},
        {"title": "Do Not Share Phone Number Publicly",
         "detail": "Remove your phone number from public profiles wherever possible.",
         "priority": "high", "icon": "phone-off"},
        {"title": "Use VoIP Number for Sign-Ups",
         "detail": "Register public services with a disposable VoIP number to protect your real one.",
         "priority": "medium", "icon": "phone"},
    ],
    "general": [
        {"title": "Monitor with HaveIBeenPwned",
         "detail": "Sign up for breach alerts at haveibeenpwned.com to get notified instantly.",
         "priority": "medium", "icon": "bell"},
        {"title": "Use a VPN",
         "detail": "A VPN masks your IP and reduces correlation attacks across platforms.",
         "priority": "medium", "icon": "wifi"},
        {"title": "Conduct Regular Digital Audits",
         "detail": "Periodically review what personal information is publicly accessible.",
         "priority": "low", "icon": "search"},
    ],
}


class ExposureEngine:
    def __init__(self, db_manager):
        self.db = db_manager

    # ──────────────────────────────────────────────────────────────────────────
    def run_scan(self, email="", username="", phone=""):
        result = {
            "scan_id":    self._gen_scan_id(),
            "scan_time":  datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC"),
            "inputs":     {"email": email, "username": username, "phone": phone},
            "exposures":  {"email": [], "username": [], "phone": []},
            "platform_summary": [],
            "risk_score": 0,
            "risk_level": {},
            "recommendations": [],
            "stats": {
                "total_exposures": 0,
                "email_exposures": 0,
                "username_exposures": 0,
                "phone_exposures": 0,
            }
        }

        raw_score = 0
        all_platforms = {}
        recs = []

        # ── Email scan ────────────────────────────────────────────────────────
        if email:
            rows = self.db.query_email(email)
            result["exposures"]["email"] = rows
            result["stats"]["email_exposures"] = len(rows)
            for r in rows:
                w = SEVERITY_WEIGHTS.get(r["severity"], 5)
                if r["platform"] in SENSITIVE_PLATFORMS:
                    w = int(w * 1.5)
                raw_score += w
                all_platforms[r["platform"]] = {
                    "platform": r["platform"],
                    "category": r["category"],
                    "severity": r["severity"],
                    "sources":  all_platforms.get(r["platform"], {}).get("sources", 0) + 1,
                }
            if rows:
                recs += RECOMMENDATIONS["email"]

        # ── Username scan ─────────────────────────────────────────────────────
        if username:
            rows = self.db.query_username(username)
            result["exposures"]["username"] = rows
            result["stats"]["username_exposures"] = len(rows)
            for r in rows:
                w = SEVERITY_WEIGHTS.get(r["severity"], 5)
                if r["platform"] in SENSITIVE_PLATFORMS:
                    w = int(w * 1.4)
                raw_score += w
                all_platforms[r["platform"]] = {
                    "platform": r["platform"],
                    "category": r["category"],
                    "severity": r["severity"],
                    "sources":  all_platforms.get(r["platform"], {}).get("sources", 0) + 1,
                }
            if rows:
                recs += RECOMMENDATIONS["username"]

        # ── Phone scan ────────────────────────────────────────────────────────
        if phone:
            rows = self.db.query_phone(phone)
            result["exposures"]["phone"] = rows
            result["stats"]["phone_exposures"] = len(rows)
            for r in rows:
                w = SEVERITY_WEIGHTS.get(r["severity"], 5)
                if r["platform"] in SENSITIVE_PLATFORMS:
                    w = int(w * 1.6)
                raw_score += w
                all_platforms[r["platform"]] = {
                    "platform": r["platform"],
                    "category": r["category"],
                    "severity": r["severity"],
                    "sources":  all_platforms.get(r["platform"], {}).get("sources", 0) + 1,
                }
            if rows:
                recs += RECOMMENDATIONS["phone"]

        # ── General recs always appended ─────────────────────────────────────
        recs += RECOMMENDATIONS["general"]

        # ── Finalize ──────────────────────────────────────────────────────────
        total = (result["stats"]["email_exposures"] +
                 result["stats"]["username_exposures"] +
                 result["stats"]["phone_exposures"])
        result["stats"]["total_exposures"] = total

        final_score = min(100, raw_score)
        result["risk_score"]       = final_score
        result["risk_level"]       = classify_risk(final_score)
        result["platform_summary"] = sorted(
            list(all_platforms.values()),
            key=lambda x: SEVERITY_WEIGHTS.get(x["severity"], 0),
            reverse=True
        )

        # Deduplicate recommendations by title
        seen = set()
        unique_recs = []
        for r in recs:
            if r["title"] not in seen:
                seen.add(r["title"])
                unique_recs.append(r)
        result["recommendations"] = unique_recs

        # ── Log scan ──────────────────────────────────────────────────────────
        self.db.log_scan(email, username, phone,
                         final_score, result["risk_level"]["level"])

        return result

    @staticmethod
    def _gen_scan_id():
        import uuid
        return str(uuid.uuid4())[:8].upper()
