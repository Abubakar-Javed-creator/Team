"""
╔══════════════════════════════════════════════════════════════════════════════╗
║          AEGIS CYBER-FORTRESS SOLUTIONS — Security Simulation v2.4.1        ║
║          Educational Console Simulation | Python 3.7+                       ║
╚══════════════════════════════════════════════════════════════════════════════╝

Simulates a malware attack (SYN Flood + Payload Injection) on a fictional
network, then shows IDPS detection and firewall/honeypot prevention.
Pure educational demonstration — no real network activity occurs.
"""

import time
import sys
import os
import random
from datetime import datetime
from typing import Optional


# ── ANSI Color codes ──────────────────────────────────────────────────────────
class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"

    # Blues / Navy
    NAVY    = "\033[38;5;17m"
    BLUE    = "\033[38;5;27m"
    LBLUE   = "\033[38;5;39m"
    CYAN    = "\033[38;5;51m"
    CYAN2   = "\033[38;5;45m"

    # Status colors
    RED     = "\033[38;5;196m"
    RED2    = "\033[38;5;160m"
    AMBER   = "\033[38;5;214m"
    YELLOW  = "\033[38;5;226m"
    GREEN   = "\033[38;5;46m"
    GREEN2  = "\033[38;5;34m"
    WHITE   = "\033[38;5;255m"
    GRAY    = "\033[38;5;244m"
    DGRAY   = "\033[38;5;238m"

    # Backgrounds
    BG_NAVY   = "\033[48;5;17m"
    BG_BLUE   = "\033[48;5;18m"
    BG_RED    = "\033[48;5;88m"
    BG_GREEN  = "\033[48;5;22m"
    BG_AMBER  = "\033[48;5;130m"
    BG_DARK   = "\033[48;5;232m"


def supports_color() -> bool:
    """Check if terminal supports ANSI colors."""
    return hasattr(sys.stdout, 'isatty') and sys.stdout.isatty()


USE_COLOR = supports_color()


def clr(code: str, text: str) -> str:
    if USE_COLOR:
        return f"{code}{text}{C.RESET}"
    return text


def ts() -> str:
    """Current timestamp string."""
    return datetime.now().strftime("%H:%M:%S")


def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')


# ── Typewriter effect ─────────────────────────────────────────────────────────
def typewrite(text: str, delay: float = 0.012, newline: bool = True):
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(delay)
    if newline:
        print()


# ── Progress bar ──────────────────────────────────────────────────────────────
def progress_bar(pct: int, width: int = 40, color: str = C.CYAN) -> str:
    filled = int(width * pct / 100)
    bar = "█" * filled + "░" * (width - filled)
    return f"[{clr(color, bar)}] {clr(C.WHITE, str(pct)+'%')}"


def animate_progress(label: str, duration: float = 0.8, color: str = C.CYAN):
    """Animated progress bar."""
    width = 36
    steps = 20
    for i in range(steps + 1):
        pct = int(100 * i / steps)
        filled = int(width * i / steps)
        bar = "█" * filled + "░" * (width - filled)
        bar_str = f"[{clr(color, bar)}] {pct:3d}%"
        sys.stdout.write(f"\r  {clr(C.GRAY, label)}: {bar_str}  ")
        sys.stdout.flush()
        time.sleep(duration / steps)
    print()


# ── Log line printer ──────────────────────────────────────────────────────────
def log(msg: str, level: str = "SYS", delay_after: float = 0.3):
    colors = {
        "SYS":     C.GRAY,
        "ATTACK":  C.RED,
        "DETECT":  C.AMBER,
        "PREVENT": C.GREEN,
        "INFO":    C.CYAN,
        "CRIT":    C.RED2,
        "OK":      C.GREEN2,
    }
    icons = {
        "SYS":     "·",
        "ATTACK":  "✗",
        "DETECT":  "◆",
        "PREVENT": "✓",
        "INFO":    "▶",
        "CRIT":    "!!!",
        "OK":      "✓",
    }
    col  = colors.get(level, C.GRAY)
    icon = icons.get(level, "·")
    timestamp = clr(C.DGRAY, f"[{ts()}]")
    lvl_tag   = clr(col + C.BOLD, f"[{level:<7}]")
    icon_str  = clr(col, icon)
    print(f"  {timestamp} {lvl_tag} {icon_str}  {clr(col, msg)}")
    time.sleep(delay_after)


# ── Packet animation (ASCII) ──────────────────────────────────────────────────
def send_packet(src: str, dst: str, pkt_type: str, label: str,
                color: str = C.RED, steps: int = 30):
    """Animate a packet travelling from src to dst across the console."""
    width = 60
    src_s  = clr(C.GRAY, f"[{src}]")
    dst_s  = clr(C.GRAY, f"[{dst}]")
    pkt_s  = clr(color + C.BOLD, f"«{label}»")

    for i in range(0, steps + 1, 3):
        pos = int(width * i / steps)
        line = " " * pos + clr(color, "▶") + " " * (width - pos)
        sys.stdout.write(f"\r  {src_s} {line} {pkt_s} → {dst_s}   ")
        sys.stdout.flush()
        time.sleep(0.02)
    print(f"\r  {src_s} {'─' * width} {pkt_s} ✓ {dst_s}   ")


# ── Section headers ───────────────────────────────────────────────────────────
def section_header(title: str, color: str = C.CYAN, icon: str = "═"):
    width = 72
    border = clr(color, icon * width)
    padded = title.center(width - 4)
    print(f"\n  {border}")
    print(f"  {clr(color, '║')}  {clr(C.WHITE + C.BOLD, padded)}  {clr(color, '║')}")
    print(f"  {border}\n")
    time.sleep(0.2)


def sub_header(title: str, color: str = C.BLUE):
    width = 68
    line = clr(color, "─" * width)
    print(f"\n  {line}")
    print(f"  {clr(color, '▶')} {clr(C.WHITE + C.BOLD, title)}")
    print(f"  {line}")
    time.sleep(0.1)


# ── Network diagram ───────────────────────────────────────────────────────────
NETWORK_STATES: dict = {}

NODE_LABELS = {
    "attacker":  ("☠ ", "ATTACKER",   "External Threat"),
    "fw1":       ("🛡 ", "FIREWALL",   "Gen 1-2-3"),
    "idps":      ("📡", "IDPS ENGINE","Anomaly+Sig"),
    "dmz":       ("🌐", "DMZ SERVER", "Web Facing"),
    "honeypot":  ("🍯", "HONEYPOT",   "Padded Cell"),
    "fw2":       ("🔥", "INNER FW",   "Dual-Homed"),
    "vault":     ("🏦", "INNER VAULT","Crown Jewels"),
    "vpn":       ("🔒", "VPN GW",     "Enc. Tunnel"),
}

STATE_COLORS = {
    "danger":  C.RED,
    "warning": C.AMBER,
    "safe":    C.GREEN,
    "trapped": C.CYAN,
    "idle":    C.GRAY,
}


def node_str(node_id: str) -> str:
    icon, name, sub = NODE_LABELS[node_id]
    state = NETWORK_STATES.get(node_id, "idle")
    col   = STATE_COLORS.get(state, C.GRAY)
    status_char = {"danger":"✗","warning":"⚠","safe":"✓","trapped":"⌖","idle":"·"}.get(state,"·")
    return (
        f"{clr(col, '┌─────────────────┐')}\n"
        f"  {clr(col, '│')} {icon} {clr(C.WHITE+C.BOLD, name):<12}  {clr(col, '│')}\n"
        f"  {clr(col, '│')}  {clr(C.GRAY, sub):<16}{clr(col, '│')}\n"
        f"  {clr(col, '│')}  {clr(col+C.BOLD, f'[{status_char}] {state.upper():<9}')}{clr(col, '│')}\n"
        f"  {clr(col, '└─────────────────┘')}"
    )


def draw_network():
    """Print a simplified ASCII network topology."""
    print()
    # Row 1: attacker → fw1 → dmz → fw2 → vault
    for nid in ["attacker", "fw1", "dmz", "fw2", "vault"]:
        icon, name, sub = NODE_LABELS[nid]
        state = NETWORK_STATES.get(nid, "idle")
        col   = STATE_COLORS.get(state, C.GRAY)
        sym   = {"danger":"✗","warning":"⚠","safe":"✓","trapped":"⌖","idle":"·"}.get(state,"·")
        box   = f"{clr(col,'[')}{icon}{clr(C.WHITE+C.BOLD, name)}{clr(col,f'({sym})]')}"
        arrow = clr(C.BLUE, " ──▶ ")
        end   = arrow if nid != "vault" else ""
        print(f"  {box}{end}", end="")
    print()
    # Row 2: idps and honeypot underneath fw1 / dmz
    print(f"\n  {' ' * 24}", end="")
    for nid in ["idps", "honeypot", "vpn"]:
        icon, name, sub = NODE_LABELS[nid]
        state = NETWORK_STATES.get(nid, "idle")
        col   = STATE_COLORS.get(state, C.GRAY)
        sym   = {"danger":"✗","warning":"⚠","safe":"✓","trapped":"⌖","idle":"·"}.get(state,"·")
        box   = f"{clr(col,'[')}{icon}{clr(C.WHITE+C.BOLD, name)}{clr(col,f'({sym})]')}"
        print(f"{box}    ", end="")
    print("\n")


def set_node(node_id: str, state: str):
    NETWORK_STATES[node_id] = state


def reset_nodes():
    for k in NODE_LABELS:
        NETWORK_STATES[k] = "idle"


# ── Metrics display ───────────────────────────────────────────────────────────
class Metrics:
    def __init__(self):
        self.mal_packets = 0
        self.blocked     = 0
        self.integrity   = 100
        self.phase       = "IDLE"

    def show(self):
        int_col = C.GREEN if self.integrity > 80 else (C.AMBER if self.integrity > 40 else C.RED)
        ph_col  = {"IDLE":C.GRAY,"ATTACKING":C.RED,"DETECTING":C.AMBER,
                   "SECURED":C.GREEN,"RESPONDING":C.CYAN}.get(self.phase, C.GRAY)
        w = 16
        print(clr(C.BLUE, f"  {'─'*70}"))
        pkts_str  = clr(C.RED+C.BOLD,   str(self.mal_packets).ljust(w))
        blk_str   = clr(C.AMBER+C.BOLD, str(self.blocked).ljust(w))
        integ_str = clr(int_col+C.BOLD, (str(self.integrity)+'%').ljust(w))
        phase_str = clr(ph_col+C.BOLD,  self.phase)
        print(
            f"  {clr(C.GRAY,'Malicious Pkts:')} {pkts_str}"
            f"{clr(C.GRAY,'Blocked:')} {blk_str}"
            f"{clr(C.GRAY,'Integrity:')} {integ_str}"
            f"{clr(C.GRAY,'Phase:')} {phase_str}"
        )
        print(clr(C.BLUE, f"  {'─'*70}"))


M = Metrics()


# ══════════════════════════════════════════════════════════════════════════════
#  SPRINT 1 — MALWARE ATTACK
# ══════════════════════════════════════════════════════════════════════════════

def sprint_attack():
    section_header("SPRINT 1  ·  MALWARE ATTACK — SYN FLOOD + PAYLOAD INJECTION", C.RED, "═")
    reset_nodes()
    M.mal_packets = 0; M.blocked = 0; M.integrity = 100; M.phase = "ATTACKING"

    print(clr(C.GRAY, "  Objective: Attacker attempts SYN flood and HTTP payload injection"))
    print(clr(C.GRAY, "  Target   : Aegis perimeter — port 80/443 + DMZ web server"))
    print(clr(C.GRAY, "  Vector   : Layer 3 (TCP) + Layer 7 (HTTP application)"))
    time.sleep(0.5)

    sub_header("Phase A — SYN Flood Launch", C.RED)
    set_node("attacker", "danger")
    draw_network()
    M.show()

    log("SYN flood initiated — 5,000 packets/sec targeting port 80 & 443.", "ATTACK", 0.2)
    log("Generation 1 Firewall (Packet Filter): checking IP headers only.", "SYS",    0.2)
    log("Payload content NOT inspected — raw IP pass-through mode.", "ATTACK", 0.2)

    for i in range(1, 7):
        M.mal_packets += 1
        send_packet("ATTACKER", "FIREWALL-G1", "SYN", f"SYN#{i}", C.RED)
        if i == 3:
            log(f"Packet #{i}: SYN flag set. No stateful check — firewall passes it.", "ATTACK", 0.1)
    set_node("fw1", "warning")

    time.sleep(0.3)
    sub_header("Phase B — HTTP Payload Injection", C.RED)
    draw_network()

    log('Attacker embeds shell command inside HTTP request:', "ATTACK", 0.15)
    log('  GET /index.php?cmd=%3CEXEC_SHELL%3E HTTP/1.1', "CRIT",   0.2)
    log('  Host: aegis-dmz.internal', "CRIT", 0.15)
    log('  X-Forwarded-For: 185.220.101.47 (Tor Exit Node)', "CRIT", 0.2)

    M.mal_packets += 3
    send_packet("ATTACKER", "FIREWALL-G1", "PAYLOAD", "HTTP-PLY", C.RED2)
    send_packet("FIREWALL",  "DMZ-SERVER",  "PAYLOAD", "HTTP-PLY", C.RED2)
    set_node("dmz", "danger")
    M.integrity = 58
    log("BREACH: Webshell payload reached DMZ server — command executing.", "CRIT", 0.3)

    time.sleep(0.2)
    sub_header("Phase C — Lateral Movement Attempt", C.RED)
    draw_network()

    log("Enumerating internal network from compromised DMZ...", "ATTACK", 0.2)
    M.mal_packets += 8
    send_packet("DMZ-SERVER", "INNER-FW",   "LATERAL", "LMV-PKT", C.RED)
    set_node("fw2", "warning")
    send_packet("INNER-FW",   "INNER-VAULT","LATERAL", "LMV-PKT", C.RED)
    set_node("vault", "warning")
    M.integrity = 31

    log("CRITICAL: Attacker probing Inner Vault — Crown Jewels at risk!", "CRIT", 0.2)
    log("VPN gateway probe — attempting tunnel interception.", "ATTACK", 0.3)

    for _ in range(3):
        M.mal_packets += 1
        send_packet("ATTACKER", "FIREWALL-G1", "SYN", "SYN-FLD", C.RED)

    draw_network()
    M.phase = "BREACHED"
    M.show()
    animate_progress("Sprint 1 complete", 1.2, C.RED)
    log("Sprint 1 finished. System is COMPROMISED. Proceed to Sprint 2.", "INFO", 0.1)


# ══════════════════════════════════════════════════════════════════════════════
#  SPRINT 2 — IDPS DETECTION
# ══════════════════════════════════════════════════════════════════════════════

def sprint_detect():
    section_header("SPRINT 2  ·  IDPS DETECTION — ANOMALY + SIGNATURE ANALYSIS", C.AMBER, "═")
    reset_nodes()
    set_node("attacker", "danger")
    set_node("fw1",      "warning")
    set_node("dmz",      "warning")
    set_node("vault",    "warning")
    M.mal_packets = 16; M.blocked = 0; M.integrity = 31; M.phase = "DETECTING"

    print(clr(C.GRAY, "  Objective : IDPS Engine detects the attack across all 3 detection modes"))
    print(clr(C.GRAY, "  Methods   : Statistical Anomaly + Signature Matching + Packet Sniffing"))
    print(clr(C.GRAY, "  Outcome   : Alert escalated to Gen 3 Firewall controller"))
    time.sleep(0.5)
    draw_network()
    M.show()

    sub_header("Detection Layer 1 — Statistical Anomaly Engine", C.AMBER)
    set_node("idps", "warning")
    draw_network()

    log("IDPS Engine online — dual-mode: Statistical Anomaly + Signature.", "INFO", 0.2)
    log("Sampling dev_user command frequency over last 60 seconds...", "DETECT", 0.3)
    animate_progress("Sampling traffic baseline", 0.7, C.AMBER)

    log("BASELINE RATE  : 60 commands / minute  (normal developer activity)", "SYS",    0.2)
    log("OBSERVED RATE  : 5,000 commands / second  ← 8,333× above baseline", "DETECT", 0.2)
    log("ANOMALY FLAG   : Bot or automated exploit confirmed.", "CRIT",   0.3)
    send_packet("FIREWALL", "IDPS-ENGINE", "FLAG", "ANOMALY", C.AMBER)

    sub_header("Detection Layer 2 — Signature Match Engine", C.AMBER)
    log("Scanning HTTP payload against webshell signature database...", "DETECT", 0.25)
    animate_progress("Signature database scan", 0.8, C.AMBER)

    log("SIGNATURE DB   : 14,782 known webshell fingerprints loaded.", "SYS",    0.2)
    log("MATCH FOUND    : Entry #1447 — cmd= injection + null-byte padding.", "DETECT", 0.2)
    log("OBFUSCATION    : Base64 encoding layer detected in query string.", "DETECT", 0.2)
    log("CONFIDENCE     : 98.4% match — MALICIOUS payload confirmed.", "CRIT",   0.3)
    send_packet("DMZ-SERVER", "IDPS-ENGINE", "SIG", "SIG-MATCH", C.AMBER)

    sub_header("Detection Layer 3 — Packet Sniffer / Exfil Monitor", C.AMBER)
    log("Monitoring outbound data streams for anomalous egress...", "DETECT", 0.25)
    animate_progress("Scanning outbound channels", 0.6, C.AMBER)

    log("OUTBOUND STREAM: Port 4444 — 2.4 MB/s to 185.220.101.47 (Tor exit).", "DETECT", 0.2)
    log("EXFIL DETECTED : Unencrypted data stream — possible Crown Jewel theft.", "CRIT",   0.2)
    M.mal_packets = 412
    log(f"TOTAL COUNT    : {M.mal_packets} malicious packets identified and logged.", "DETECT", 0.3)

    set_node("idps", "danger")
    draw_network()
    M.phase = "ALERTED"
    M.show()

    sub_header("Alert Escalation", C.AMBER)
    log("All 3 IDPS detection layers firing simultaneously — ESCALATE.", "CRIT",   0.2)
    log("Dispatching to: Gen 3 Firewall controller.", "DETECT", 0.15)
    log("Dispatching to: Honeypot redirect engine.", "DETECT", 0.15)
    log("Dispatching to: Security Operations Center (SOC).", "DETECT", 0.3)
    send_packet("IDPS-ENGINE", "FIREWALL-G3", "ALERT", "ESCALATE", C.AMBER)
    animate_progress("Sprint 2 complete", 1.0, C.AMBER)
    log("Sprint 2 finished. Detection complete. Proceed to Sprint 3.", "INFO", 0.1)


# ══════════════════════════════════════════════════════════════════════════════
#  SPRINT 3 — PREVENTION & LOCKDOWN
# ══════════════════════════════════════════════════════════════════════════════

def sprint_prevent():
    section_header("SPRINT 3  ·  PREVENTION — FIREWALL LOCKDOWN + HONEYPOT TRAP", C.GREEN, "═")
    reset_nodes()
    set_node("attacker", "danger")
    set_node("fw1",      "warning")
    set_node("idps",     "safe")
    set_node("dmz",      "warning")
    set_node("vault",    "warning")
    set_node("fw2",      "warning")
    set_node("honeypot", "safe")
    set_node("vpn",      "safe")
    M.mal_packets = 412; M.blocked = 0; M.integrity = 31; M.phase = "RESPONDING"

    print(clr(C.GRAY, "  Objective : Neutralise the attack, contain the attacker, restore integrity"))
    print(clr(C.GRAY, "  Methods   : Gen 3 DPI + Stateful drop + Honeypot trap + Vault isolation"))
    time.sleep(0.5)
    draw_network()
    M.show()

    # ── Gen 3 DPI ──────────────────────────────────────────────────────────────
    sub_header("Countermeasure 1 — Generation 3 Deep Packet Inspection", C.GREEN)
    log("GEN 3 DPI: Reading the letter inside the envelope (Layer 7 inspection).", "PREVENT", 0.2)
    log("Injecting firewall rule: DROP all SYN from 185.220.101.x/24.", "PREVENT", 0.2)

    for i in range(1, 4):
        send_packet("ATTACKER", "FIREWALL-G3", "SYN", f"SYN#{i}", C.RED)
        M.blocked += 1
        log(f"  ✓ SYN packet #{i} BLOCKED and logged.", "OK", 0.1)
    set_node("fw1", "safe")
    log("Rate limit enforced — max 50 req/sec on port 80/443.", "PREVENT", 0.25)

    # ── Gen 2 Stateful ─────────────────────────────────────────────────────────
    sub_header("Countermeasure 2 — Generation 2 Stateful Inspection", C.GREEN)
    log("GEN 2 STATEFUL: Checking session origin — was this initiated internally?", "PREVENT", 0.2)
    log("Attacker's reply packets: NO matching internal session found.", "PREVENT", 0.2)
    send_packet("ATTACKER", "FIREWALL-G2", "PAYLOAD", "HTTP-PLY", C.RED)
    M.blocked += 1
    set_node("fw1", "safe")
    log("✓ SESSION KILLED: Stateful rule — if host didn't initiate, DROP.", "OK", 0.3)

    # ── Honeypot ───────────────────────────────────────────────────────────────
    sub_header("Countermeasure 3 — Honeypot / Padded Cell Activation", C.GREEN)
    log("HONEYPOT REDIRECT: DMZ probe silently rerouted to fake Financial DB.", "PREVENT", 0.2)
    send_packet("DMZ-SERVER", "HONEYPOT", "REDIRECT", "→HONEYPOT", C.CYAN)
    set_node("honeypot", "trapped")
    log("✓ ATTACKER INSIDE PADDED CELL — simulated environment active.", "OK", 0.2)
    log('  Attacker is now trying to steal "encrypted files"...', "PREVENT", 0.15)
    log("  (Those files are 4 GB of Rick Astley — Never Gonna Give You Up)", "PREVENT", 0.3)

    print()
    print(clr(C.CYAN, "  ┌─────────────────────────────────────────────────────┐"))
    print(clr(C.CYAN, "  │") + clr(C.WHITE, "  🍯  PADDED CELL ACTIVE — Attacker trapped inside    ") + clr(C.CYAN, "│"))
    print(clr(C.CYAN, "  │") + clr(C.GRAY,  "       Time in cell: ") + clr(C.AMBER, "00:00:01 ... 00:00:02 ...      ") + clr(C.CYAN, "│"))
    print(clr(C.CYAN, "  │") + clr(C.GRAY,  '       Files served: "financial_data_2024.enc"        ') + clr(C.CYAN, "│"))
    print(clr(C.CYAN, "  │") + clr(C.GRAY,  "       Actually     : Rick Astley lyrics × 4 GB       ") + clr(C.CYAN, "│"))
    print(clr(C.CYAN, "  └─────────────────────────────────────────────────────┘"))
    print()
    time.sleep(0.4)

    # ── IDPS port close ────────────────────────────────────────────────────────
    sub_header("Countermeasure 4 — Active IDPS Auto-Response", C.GREEN)
    log("ACTIVE IDPS: Auto-closing port 4444 — exfil signature match.", "PREVENT", 0.2)
    M.blocked = 412
    log(f"✓ All {M.blocked} malicious packets BLOCKED and written to forensic log.", "OK", 0.3)

    # ── DMZ clean ──────────────────────────────────────────────────────────────
    sub_header("Countermeasure 5 — DMZ Sanitisation & Vault Isolation", C.GREEN)
    log("GEN 3 APP LAYER: Webshell payload stripped. DMZ patched.", "PREVENT", 0.2)
    animate_progress("Sanitising DMZ server", 0.7, C.GREEN)
    set_node("dmz", "safe")
    log("✓ DMZ server clean. Vulnerability patched.", "OK", 0.2)

    log("SCREENED SUBNET: Dual-firewall — no direct DMZ → Vault path exists.", "PREVENT", 0.2)
    send_packet("HONEYPOT", "INNER-VAULT", "OK", "VERIFY", C.GREEN)
    set_node("vault", "safe")
    set_node("fw2", "safe")
    log("✓ Inner Vault: ISOLATED. Crown Jewels secured.", "OK", 0.3)

    # ── VPN ────────────────────────────────────────────────────────────────────
    sub_header("Countermeasure 6 — VPN & Wireless Security Verification", C.GREEN)
    log("VPN TUNNEL: All consultant traffic verified — AES-256 encrypted.", "PREVENT", 0.2)
    log("WIRELESS   : WPA3 confirmed on office Wi-Fi — no free-for-all.", "PREVENT", 0.2)
    set_node("vpn", "safe")
    log("✓ VPN Gateway: Secure. No lateral spread via consultant tunnels.", "OK", 0.3)

    # ── Biometric note ─────────────────────────────────────────────────────────
    sub_header("Security Note — Biometric Acceptability Lesson", C.BLUE)
    log("CEO voice biometric failed during head-cold incident (see report).", "SYS",     0.2)
    log("System played 10-hour 'Girl from Ipanema' loop. CEO trapped 3 hrs.", "SYS",    0.2)
    log("✓ Manual override protocol activated. Lesson: plan for biometric failure!", "OK", 0.3)

    # ── Final state ────────────────────────────────────────────────────────────
    draw_network()
    M.integrity = 100
    M.phase = "SECURED"
    M.show()
    animate_progress("Sprint 3 complete — system secured", 1.4, C.GREEN)

    print()
    section_header("AEGIS CYBER-FORTRESS — ALL SYSTEMS SECURED  ✓", C.GREEN, "═")
    print(clr(C.GREEN,  "  ✓  SYN Flood: BLOCKED (412 / 412 packets dropped)"))
    print(clr(C.GREEN,  "  ✓  Payload Injection: STRIPPED at Gen 3 DPI layer"))
    print(clr(C.GREEN,  "  ✓  Lateral Movement: PREVENTED by screened subnet"))
    print(clr(C.GREEN,  "  ✓  Attacker: CONTAINED in Padded Cell (Rick Astley mode)"))
    print(clr(C.GREEN,  "  ✓  Inner Vault: INTACT — Crown Jewels secured"))
    print(clr(C.CYAN,   "  ✓  System Integrity: 100%"))
    print()


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN MENU
# ══════════════════════════════════════════════════════════════════════════════

def print_banner():
    banner = r"""
  ╔══════════════════════════════════════════════════════════════════════════╗
  ║                                                                          ║
  ║    █████╗ ███████╗ ██████╗ ██╗███████╗     ██████╗██╗   ██╗             ║
  ║   ██╔══██╗██╔════╝██╔════╝ ██║██╔════╝    ██╔════╝╚██╗ ██╔╝             ║
  ║   ███████║█████╗  ██║  ███╗██║███████╗    ██║      ╚████╔╝              ║
  ║   ██╔══██║██╔══╝  ██║   ██║██║╚════██║    ██║       ╚██╔╝               ║
  ║   ██║  ██║███████╗╚██████╔╝██║███████║    ╚██████╗   ██║                ║
  ║   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═╝╚══════╝    ╚═════╝   ╚═╝                ║
  ║                                                                          ║
  ║         C Y B E R - F O R T R E S S   S O L U T I O N S                ║
  ║         Security Operations Simulation  ·  v2.4.1  ·  Python           ║
  ╚══════════════════════════════════════════════════════════════════════════╝
"""
    print(clr(C.CYAN, banner))
    print(clr(C.GRAY, "  An educational simulation of a malware attack and its defenses."))
    print(clr(C.GRAY, "  No real network activity occurs. For learning purposes only.\n"))


def print_menu():
    print(clr(C.BLUE, "  ┌──────────────────────────────────────────────┐"))
    print(clr(C.BLUE, "  │") + clr(C.WHITE + C.BOLD, "          SIMULATION MENU                     ") + clr(C.BLUE, "│"))
    print(clr(C.BLUE, "  ├──────────────────────────────────────────────┤"))
    print(clr(C.BLUE, "  │") + f"  {clr(C.RED+C.BOLD,'[1]')}  Sprint 1 — Malware Attack               " + clr(C.BLUE, "│"))
    print(clr(C.BLUE, "  │") + f"  {clr(C.AMBER+C.BOLD,'[2]')}  Sprint 2 — IDPS Detection               " + clr(C.BLUE, "│"))
    print(clr(C.BLUE, "  │") + f"  {clr(C.GREEN+C.BOLD,'[3]')}  Sprint 3 — Prevention & Lockdown        " + clr(C.BLUE, "│"))
    print(clr(C.BLUE, "  │") + f"  {clr(C.CYAN+C.BOLD,'[A]')}  Run ALL 3 Sprints (full simulation)     " + clr(C.BLUE, "│"))
    print(clr(C.BLUE, "  │") + f"  {clr(C.GRAY+C.BOLD,'[Q]')}  Quit                                    " + clr(C.BLUE, "│"))
    print(clr(C.BLUE, "  └──────────────────────────────────────────────┘"))
    print()


def main():
    clear_screen()
    print_banner()

    while True:
        print_menu()
        try:
            choice = input(clr(C.CYAN, "  aegis-soc") + clr(C.GRAY, " » ") + clr(C.WHITE, "")).strip().upper()
        except (KeyboardInterrupt, EOFError):
            print(clr(C.GRAY, "\n\n  Simulation terminated. Stay secure.\n"))
            sys.exit(0)

        if choice == "1":
            clear_screen()
            sprint_attack()
        elif choice == "2":
            clear_screen()
            sprint_detect()
        elif choice == "3":
            clear_screen()
            sprint_prevent()
        elif choice == "A":
            clear_screen()
            sprint_attack()
            input(clr(C.GRAY, "\n  Press Enter to continue to Sprint 2…"))
            clear_screen()
            sprint_detect()
            input(clr(C.GRAY, "\n  Press Enter to continue to Sprint 3…"))
            clear_screen()
            sprint_prevent()
        elif choice == "Q":
            print(clr(C.GRAY, "\n  Aegis simulation ended. Stay secure.\n"))
            sys.exit(0)
        else:
            print(clr(C.RED, f"  Unknown command '{choice}'. Enter 1, 2, 3, A, or Q.\n"))
            continue

        input(clr(C.GRAY, "\n  Press Enter to return to menu…"))
        clear_screen()
        print_banner()


if __name__ == "__main__":
    main()
